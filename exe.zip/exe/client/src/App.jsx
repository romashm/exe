import {
  React,
  useState,
  useEffect
} from 'react';

function App() {
  useEffect(() => {
      console.log(process.env.DJANGO_CLIENT_API_ENDPOINT)
      async function fetchData() {
          try {
              const response = await fetch(`${process.env.DJANGO_CLIENT_API_ENDPOINT}cores`)
              if (!response.ok) {
                  throw new Error('Network response is bad')
              }
              const result = await response.json();
              console.log(result)
              setdata(result);
          } catch (error) {
              console.error('Error fetching data:', error)
          }
      }

      fetchData()
  }, [])

  return ( 
    <></>
  );
}

export default App;