from rest_framework.viewsets import ModelViewSet
from ..models import Core
from .serializers import PostSerializer


class PostViewSet(ModelViewSet):
    queryset = Core.objects.all()
    serializer_class = PostSerializer
    